package models

//配置项
type Config struct {
	Id        int    //
	Key       string //键
	Value     string //值
	Statement string //描述
	Cate      string //分类
}
