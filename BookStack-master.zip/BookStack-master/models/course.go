package models

type Course struct {
	Id          int
	Cover       string
	Title       string
	Keywords    string
	Teacher     string
	Menu        string
	Description string
}
