package routers

func init() {
	bookChatRouters()
	webRouter()
}
